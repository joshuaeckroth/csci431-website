package cc.artifice.csci431.studentadvisor;

/**
 * Created by JoshuaEckroth on 9/24/16.
 */
public class Semester {
    private String season;
    private int year;

    public Semester(String season, int year) {
        this.season = season;
        this.year = year;
    }

    public String getSeason() {
        return season;
    }

    public int getYear() {
        return year;
    }

    @Override
    public String toString() {
        return "Semester{" +
                "season='" + season + '\'' +
                ", year=" + year +
                '}';
    }
}
