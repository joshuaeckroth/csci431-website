package cc.artifice.csci431.studentadvisor;

/**
 * Created by JoshuaEckroth on 9/24/16.
 */
public class Course {
    private String name;
    private String id;
    private int units;

    public Course(String name, String id, int units) {
        this.name = name;
        this.id = id;
        this.units = units;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public int getUnits() {
        return units;
    }

    @Override
    public String toString() {
        return "Course{" +
                "name='" + name + '\'' +
                ", id='" + id + '\'' +
                ", units=" + units +
                '}';
    }

}
