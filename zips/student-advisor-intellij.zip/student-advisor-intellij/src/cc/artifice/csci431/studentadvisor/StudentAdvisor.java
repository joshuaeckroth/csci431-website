package cc.artifice.csci431.studentadvisor;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class StudentAdvisor {

    public static void main(String[] args) {
        KieContainer kc = KieServices.Factory.get().getKieClasspathContainer();
        KieSession ksession = kc.newKieSession("StudentAdvisorKS");

        Student johndoe = new Student("John", "Doe");
        ksession.insert(johndoe);
        Course csci221 = new Course("Software Development I", "CSCI221", 4);
        Course csci142 = new Course("Introduction to Computer Science II", "CSCI142", 4);
        ksession.insert(csci221);
        ksession.insert(csci142);
        CourseAttempt ca = new CourseAttempt(johndoe, csci142, new Semester("Fall", 2015), 3.5);
        ksession.insert(ca);

        ksession.fireAllRules();


    }
}
