package cc.artifice.csci431.studentadvisor;

/**
 * Created by JoshuaEckroth on 9/24/16.
 */
public class CourseAttempt {
    private Student student;
    private Course course;
    private Semester semester;
    private double gpa;

    public CourseAttempt(Student student, Course course, Semester semester, double gpa) {
        this.student = student;
        this.course = course;
        this.semester = semester;
        this.gpa = gpa;
    }

    public Student getStudent() {
        return student;
    }

    public Course getCourse() {
        return course;
    }

    public Semester getSemester() {
        return semester;
    }

    public double getGpa() {
        return gpa;
    }

    @Override
    public String toString() {
        return "CourseAttempt{" +
                "student=" + student +
                ", course=" + course +
                ", semester=" + semester +
                ", gpa=" + gpa +
                '}';
    }
}
